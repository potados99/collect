"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const repository_1 = __importDefault(require("../data/repository"));
function getService() {
    return createService();
}
exports.default = getService;
function createService() {
    return {
        getMessage: async function (channelName, messageId) {
            const repo = await (0, repository_1.default)(channelName);
            return await repo.getMessage(messageId);
        },
        getAllMessages: async function (channelName) {
            const repo = await (0, repository_1.default)(channelName);
            return await repo.getAllMessages();
        },
        addMessage: async function ({ channelName, ...params }) {
            const repo = await (0, repository_1.default)(channelName);
            const message = {
                channelName,
                ...params,
            };
            await repo.addMessage(message);
        },
        deleteMessages: async function (channelName) {
            const repo = await (0, repository_1.default)(channelName);
            await repo.deleteAllMessages();
        },
    };
}
//# sourceMappingURL=service.js.map