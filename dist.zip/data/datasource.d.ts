export declare function getChannelDataSource(channelName: string): Promise<string>;
export declare function getBackupDataSource(): Promise<string>;
