"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const service_1 = __importDefault(require("../../domain/service"));
const event_1 = require("../event");
const response_1 = require("../response");
async function handlePost(event) {
    const content = (0, event_1.getBody)(event);
    if (content == null) {
        return (0, response_1.errorResponse)(400, 'Empty body');
    }
    const { channelName } = await (0, event_1.getChannelNameAndMessageId)(event);
    const metadata = (0, event_1.getMetadata)(event);
    await (0, service_1.default)().addMessage({
        channelName,
        content,
        ...metadata,
    });
    return {
        statusCode: 200,
        body: '굿\n',
    };
}
exports.default = handlePost;
//# sourceMappingURL=handlePost.js.map