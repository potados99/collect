import handleGet from "./web/routes/handleGet";
import handlePost from "./web/routes/handlePost";
import handleDelete from "./web/routes/handleDelete";
import { APIGatewayProxyEvent, APIGatewayProxyResult } from "aws-lambda";
export declare function getRoute(event: APIGatewayProxyEvent): Promise<typeof handleGet | typeof handlePost | typeof handleDelete>;
export declare const lambdaHandler: (event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;
