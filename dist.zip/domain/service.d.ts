export type AddMessageParams = {
    channelName: string;
    timeEpoch: number;
    userAgent: string | null;
    sourceIp: string;
    content: string;
};
export default function getService(): {
    getMessage: (channelName: string, messageId: string) => Promise<import("./types").Message>;
    getAllMessages: (channelName: string) => Promise<import("./types").Message[]>;
    addMessage: ({ channelName, ...params }: AddMessageParams) => Promise<void>;
    deleteMessages: (channelName: string) => Promise<void>;
};
