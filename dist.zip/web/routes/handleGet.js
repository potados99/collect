"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const service_1 = __importDefault(require("../../domain/service"));
const event_1 = require("../event");
const response_1 = require("../response");
async function handleGet(event) {
    const { channelName, messageId } = await (0, event_1.getChannelNameAndMessageId)(event);
    const apiCall = (0, event_1.isApiCall)(event);
    if (messageId == null) {
        return await getAllMessages(channelName, apiCall);
    }
    else {
        return await getMessage(channelName, messageId, apiCall);
    }
}
exports.default = handleGet;
async function getAllMessages(channelName, apiCall) {
    const messages = await (0, service_1.default)().getAllMessages(channelName);
    if (apiCall) {
        return (0, response_1.jsonResponse)(messages);
    }
    else {
        return (0, response_1.htmlResponse)('messages', { channelName, messages });
    }
}
async function getMessage(channelName, messageId, apiCall) {
    const message = await (0, service_1.default)().getMessage(channelName, messageId);
    if (message == null) {
        return (0, response_1.errorResponse)(404, 'Message not found.');
    }
    if (apiCall) {
        return (0, response_1.jsonResponse)(message);
    }
    else {
        return (0, response_1.htmlResponse)('message', { channelName, message });
    }
}
//# sourceMappingURL=handleGet.js.map