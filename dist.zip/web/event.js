"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getMethod = exports.getMetadata = exports.getBody = exports.isApiCall = exports.getChannelNameAndMessageId = void 0;
async function getChannelNameAndMessageId(event) {
    const { pathParameters } = event;
    if (pathParameters == null) {
        return {
            channelName: "default",
            messageId: undefined,
        };
    }
    const { channel, message } = pathParameters;
    return {
        channelName: channel !== null && channel !== void 0 ? channel : "default",
        messageId: message,
    };
}
exports.getChannelNameAndMessageId = getChannelNameAndMessageId;
function isApiCall(event) {
    var _a;
    const { requestContext: { identity: { userAgent }, }, queryStringParameters, } = event;
    const isCurl = userAgent != null && userAgent.includes("curl");
    const isApiCall = ((_a = queryStringParameters === null || queryStringParameters === void 0 ? void 0 : queryStringParameters.response) === null || _a === void 0 ? void 0 : _a.toLowerCase()) === "api";
    return isCurl || isApiCall;
}
exports.isApiCall = isApiCall;
function getBody(event) {
    const { isBase64Encoded, body } = event;
    return isBase64Encoded ? Buffer.from(body || "", "base64").toString("utf8") : body;
}
exports.getBody = getBody;
function getMetadata(event) {
    const { requestContext: { requestTimeEpoch, identity: { userAgent, sourceIp }, }, } = event;
    return {
        timeEpoch: requestTimeEpoch,
        userAgent,
        sourceIp,
    };
}
exports.getMetadata = getMetadata;
const supportedMethods = ["get", "post", "delete"];
function getMethod(event) {
    const { httpMethod } = event;
    const normalized = httpMethod.toLowerCase();
    const method = supportedMethods.find((m) => m === normalized);
    if (method == null) {
        throw new Error(`Unsupported method: ${httpMethod}`);
    }
    return method;
}
exports.getMethod = getMethod;
//# sourceMappingURL=event.js.map