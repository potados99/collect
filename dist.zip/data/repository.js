"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const crypto_1 = require("crypto");
const fs_1 = require("fs");
const datasource_1 = require("./datasource");
async function getRepository(channelName) {
    return createRepositoryWithDataSources(await (0, datasource_1.getChannelDataSource)(channelName), await (0, datasource_1.getBackupDataSource)());
}
exports.default = getRepository;
function createRepositoryWithDataSources(primaryDataSource, backupDataSource) {
    return {
        getAllMessages: async function () {
            const fileContent = await fs_1.promises.readFile(primaryDataSource).then((buffer) => buffer.toString());
            return JSON.parse(fileContent);
        },
        getMessage: async function (messageId) {
            const allMessages = await this.getAllMessages();
            if (['last', 'latest'].includes(messageId.toLowerCase())) {
                return allMessages.pop();
            }
            return allMessages.filter((message) => message.id === messageId).pop();
        },
        addMessage: async function ({ channelName, timeEpoch, userAgent, sourceIp, content }) {
            const allMessages = await this.getAllMessages();
            const newMessage = {
                id: (0, crypto_1.randomUUID)(),
                channel: channelName,
                timestamp: timeEpoch,
                date: new Date(timeEpoch).toLocaleString('ko-KR', { timeZone: 'Asia/Seoul' }),
                userAgent,
                sourceIp,
                body: content,
            };
            allMessages.push(newMessage);
            const fileContent = JSON.stringify(allMessages, null, 4);
            await fs_1.promises.writeFile(primaryDataSource, fileContent);
            await fs_1.promises.writeFile(backupDataSource, fileContent);
        },
        deleteAllMessages: async function () {
            await fs_1.promises.writeFile(primaryDataSource, '[]');
        },
    };
}
//# sourceMappingURL=repository.js.map