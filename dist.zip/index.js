"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.lambdaHandler = exports.getRoute = void 0;
const handleGet_1 = __importDefault(require("./web/routes/handleGet"));
const handlePost_1 = __importDefault(require("./web/routes/handlePost"));
const handleDelete_1 = __importDefault(require("./web/routes/handleDelete"));
const event_1 = require("./web/event");
async function getRoute(event) {
    const routes = {
        get: handleGet_1.default,
        post: handlePost_1.default,
        delete: handleDelete_1.default,
    };
    const method = (0, event_1.getMethod)(event);
    const route = routes[method];
    if (route == null) {
        throw new Error(`Unknown method: [${method}]`);
    }
    return route;
}
exports.getRoute = getRoute;
const lambdaHandler = async (event) => {
    try {
        const route = await getRoute(event);
        return route(event);
    }
    catch (err) {
        console.log(err);
        return {
            statusCode: 500,
            body: JSON.stringify({
                message: "some error happened",
            }),
        };
    }
};
exports.lambdaHandler = lambdaHandler;
//# sourceMappingURL=index.js.map