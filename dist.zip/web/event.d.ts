import { APIGatewayProxyEvent } from "aws-lambda";
export declare function getChannelNameAndMessageId(event: APIGatewayProxyEvent): Promise<{
    channelName: string;
    messageId: string | undefined;
}>;
export declare function isApiCall(event: APIGatewayProxyEvent): boolean;
export declare function getBody(event: APIGatewayProxyEvent): string | null;
export declare function getMetadata(event: APIGatewayProxyEvent): {
    timeEpoch: number;
    userAgent: string | null;
    sourceIp: string;
};
declare const supportedMethods: readonly ["get", "post", "delete"];
export declare function getMethod(event: APIGatewayProxyEvent): (typeof supportedMethods)[number];
export {};
