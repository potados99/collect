import { APIGatewayProxyEvent } from 'aws-lambda';
export default function handlePost(event: APIGatewayProxyEvent): Promise<{
    statusCode: number;
    body: string;
}>;
