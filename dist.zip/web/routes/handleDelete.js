"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const service_1 = __importDefault(require("../../domain/service"));
const event_1 = require("../event");
async function handleDelete(event) {
    const { channelName } = await (0, event_1.getChannelNameAndMessageId)(event);
    await (0, service_1.default)().deleteMessages(channelName);
    return {
        statusCode: 200,
        body: '굿\n',
    };
}
exports.default = handleDelete;
//# sourceMappingURL=handleDelete.js.map