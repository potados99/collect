import { APIGatewayProxyEvent } from 'aws-lambda';
export default function handleDelete(event: APIGatewayProxyEvent): Promise<{
    statusCode: number;
    body: string;
}>;
