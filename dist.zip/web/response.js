"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.errorResponse = exports.jsonResponse = exports.htmlResponse = void 0;
const pug_1 = __importDefault(require("pug"));
const path_1 = __importDefault(require("path"));
const pugPath = 'views';
function htmlResponse(template, data) {
    console.log(__dirname);
    const templatePath = path_1.default.join(__dirname, pugPath, `${template}.pug`);
    const compiled = pug_1.default.compileFile(templatePath);
    return {
        statusCode: 200,
        headers: {
            'Content-Type': 'text/html',
        },
        body: compiled(data),
    };
}
exports.htmlResponse = htmlResponse;
function jsonResponse(data) {
    return {
        statusCode: 200,
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(data, null, 4),
    };
}
exports.jsonResponse = jsonResponse;
function errorResponse(statusCode, message) {
    return {
        statusCode,
        body: message,
    };
}
exports.errorResponse = errorResponse;
//# sourceMappingURL=response.js.map