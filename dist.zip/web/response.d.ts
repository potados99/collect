export declare function htmlResponse(template: string, data: any): {
    statusCode: number;
    headers: {
        'Content-Type': string;
    };
    body: string;
};
export declare function jsonResponse(data: any): {
    statusCode: number;
    headers: {
        'Content-Type': string;
    };
    body: string;
};
export declare function errorResponse(statusCode: number, message: string): {
    statusCode: number;
    body: string;
};
