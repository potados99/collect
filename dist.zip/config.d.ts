declare const _default: {
    storageDir: string;
};
export default _default;
