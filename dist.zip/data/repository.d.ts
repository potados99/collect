import { AddMessageParams } from '../domain/service';
import { Message } from '../domain/types';
export default function getRepository(channelName: string): Promise<{
    getAllMessages: () => Promise<Message[]>;
    getMessage: (messageId: string) => Promise<Message>;
    addMessage: ({ channelName, timeEpoch, userAgent, sourceIp, content }: AddMessageParams) => Promise<void>;
    deleteAllMessages: () => Promise<void>;
}>;
