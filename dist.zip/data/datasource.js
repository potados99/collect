"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getBackupDataSource = exports.getChannelDataSource = void 0;
const path_1 = __importDefault(require("path"));
const fs_1 = require("fs");
const config_1 = __importDefault(require("../config"));
const basePath = config_1.default.storageDir;
async function getChannelDataSource(channelName) {
    const channelNameSanitized = channelName.replace(/\//g, "").replace(/\./g, "").trim();
    if (!channelNameSanitized) {
        throw new Error(`Invalid channel name: [${channelName}]`);
    }
    const filePath = path_1.default.join(basePath, "channels", `${channelNameSanitized}.json`);
    await touch(filePath, "[]");
    return filePath;
}
exports.getChannelDataSource = getChannelDataSource;
async function getBackupDataSource() {
    const filePath = path_1.default.join(basePath, `combined.json`);
    await touch(filePath, "[]");
    return filePath;
}
exports.getBackupDataSource = getBackupDataSource;
async function touch(filePath, content = "[]") {
    try {
        await fs_1.promises.access(filePath);
    }
    catch (e) {
        await fs_1.promises.writeFile(filePath, content);
    }
}
//# sourceMappingURL=datasource.js.map