import { APIGatewayProxyEvent } from 'aws-lambda';
export default function handleGet(event: APIGatewayProxyEvent): Promise<{
    statusCode: number;
    body: string;
}>;
